package com.victor.spring_boot_bertoti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBertotiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBertotiApplication.class, args);
	}

}
