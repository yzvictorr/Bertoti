package com.victor.spring_boot_bertoti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBertotiApplicationTests {

	@Test
	void contextLoads() {
	}

}
